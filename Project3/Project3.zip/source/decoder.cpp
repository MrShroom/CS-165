#include <iostream>
#include <bitset>
#include <vector>
#include <tuplet.h>
#include <options.h>

byte *string_reference_tuplet::encode(const Options& opt, std::vector<encoded_tuplet>& res) {

}

byte *character_tuplet::encode(const Options& opt, std::vector<encoded_tuplet> &t) {

}

